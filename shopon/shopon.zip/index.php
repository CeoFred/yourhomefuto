<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>    
    <title>ShopON | yourhomefuto.com.ng</title>
    <?php require'inc/header.php'; ?>
</head>

<body style="background: url(../img/food.jpg);">
<header>
<?php require'inc/nav.php'; ?>        
 </header>


 <div class="center" style="margin-top: 100px;">
   <h1 style="color: white;font-weight: bolder;">Service Comming soon
   <i class="fa fa-signal"></i></h1>
 </div>
 <div>
  <?php

include'inc/footer.php';
  include'inc/navscript.php';
  ?>

</div>
</body>
</html>