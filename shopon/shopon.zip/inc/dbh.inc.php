<?php
 	
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "yourhome_futo";


$conn = mysqli_connect($dbhost ,$dbuser, $dbpassword, $dbname)
?>
