<footer class="fixed-bottom" style="font-family: 'nunito','sans-serif';color: white;background-color:#505050;margin-top:10px;">
    <div class="container-fluid">
        
    <div style="text-align: center;">
    © 2018 - Yourhomefuto.com.ng All rights reserved
	
    </div>
    </div>
    </footer>