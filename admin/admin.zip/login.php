<!DOCTYPE html>
<html>
<head>
	<title>Login Admin</title>
	<?php
include'inc/header.php';
	?>
</head>
<body>
<?php
include'inc/nav.php';
?>



<?php if(isset($_SESSION['error'])){ ?>
<div class="error" style="background-color: rgba(244,0,0,1);text-align: center;font-size: 1.2em;padding: 10px;color:#fff">
<?php echo $_SESSION['error'];unset($_SESSION['error']); ?>
</div>
<?php
} 
?>	
<br>
<?php if(isset($_SESSION['good'])){ ?>
<div class="error" style="background-color: rgba(0,153,51,1);text-align: center;font-size: 1.2em;padding: 10px;font-family:;">
<?php echo $_SESSION['good'];unset($_SESSION['good']); ?>
</div>
<?php
} 
?>
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-6 col-lg-5 col-lg-offset-4" align="center">
	
<form method="post" action="inc/login.inc.php">
	<input type="text" class="form-control" name="email">
	<input type="password" name="password" class="form-control">
	<button type="submit" class="btn btn-success" name="submit">Login</button>
</form>		
		</div>
	</div>
	
</div>


</body>
</html>