<?php
session_start();
	require 'inc/dbh.inc.php';
	if(!isset($_SESSION['adminid']) & empty($_SESSION['adminid'])){
		header('location: login.php');
	}
?>
  <!DOCTYPE html>
  <html>
  <head>
    <title>Admin Dashboard</title>
    <head>
<?php include 'inc/header.php'; ?>     
    </head>
  </head>
  <body>
<?php include 'inc/nav.php'; ?>  
<div class="container-fluid">
<div class="row">
  <div class="col-md-3 col-sm-6 col-xs-6"  style="background-color:
   #006666;color:white;">
    
    <div  align="left"><span><h3 align="center">Admin<i class="fa fa-shield"></i></h3><hr>

      <img class="rounded-circle" src="../img/ceo.png" height="40" width="40">
      <?php 
echo $_SESSION['fullname'];
      ?></span>
      <a href="profile.php" class="btn btn-primary">Profile</a>
    </div>
<hr>

    <div class="justify-content-left" align="center">
    <h5 style="display: inline-block;">USERS</h5><i class="fa fa-user-circle-o" style="font-size: 30px;"></i>
  <hr>
  <div><H6>All Users<i class="fa fa-universal-access"></i></H6></div>
  <div><H6>LoggedIn Users<i class="fa fa-eye"></i></H6></div>
  <div><H6>Activate Users<i class="fa fa-check-square"></i></H6></div>
  <div><H6>Deactivate Users<i class="fa fa-close"></i></H6></div>
  <div><H6>Add Users<i class="fa fa-user-plus"></i></H6></div>
  <div><H6>Edit Users<i class="fa fa-edit"></i></H6></div>
  
  <hr>
    <h6 style="display: inline-block;">CAMPUS SERVICES</h6><i class="fa fa-gear" style="font-size: 30px;"></i>
<hr>

  <div><H6>All Services</H6></div>
  <div><H6>Approved Services</H6></div>
  <div><H6>Unapproved Services</H6></div>
  <div><H6>Delete a Service</H6></div>
  <div><H6>Add a Service</H6></div>
  </div>
</div>

  <div class="col-md-9" style="border-radius:16px;">

    <h2 style="background-color: #008080;color: white">
    CONTROL DASHBOARD<i class="fa fa-bar-chart"></i>
  </h2>
  <div class="row">
    <div class="col-md-3" style="background-color: #0099cc;margin-left: 10px;border-radius: 6px;">
      <i class="fa fa-user" style="color: white;font-size: 55px;display: inline-block;" align="left"></i><h6 style="color: white;display: inline-block;" > Registered Users</h6>
      <div align="right">

<?php
$sql = "SELECT * FROM users;";
$result = mysqli_query($conn, $sql);
$count = mysqli_num_rows($result);



?>

      <?php
echo $count;
      ?><i class="
      fa fa-spinner fa-pulse"></i></div>
      <p style="color: white;border-top:1px solid white" >View All Users<i class="fa fa-send-o"></i></p>
    </div>



     <div class="col-md-4" style="background-color:#29a329;margin-left:10px;border-radius: 6px;">
      <i class="fa fa-registered" style="color: white;font-size: 55px;display: inline-block;" align="left"></i><h6 style="color: white;display: inline-block;" > Registered Services</h6>
      <div align="right">

<?php
$sql = "SELECT * FROM services;";
$result = mysqli_query($conn, $sql);
$count = mysqli_num_rows($result);



?>

      <?php
echo $count;
      ?><i class="
      fa fa-spinner fa-pulse"></i></div>
      <p style="color: white;border-top:1px solid white" >View All Services<i class="fa fa-send-o"></i></p>
    </div>



     <div class="col-md-4" style="background-color: #cc0000;margin-left: 10px;border-radius: 6px;">
      <i class="fa fa-home" style="color: white;font-size: 55px;display: inline-block;" align="left"></i><h6 style="color: white;display: inline-block;" > Available Lodges</h6>
      <div align="right">

<?php
$sql = "SELECT * FROM lodges;";
$result = mysqli_query($conn, $sql);
$count = mysqli_num_rows($result);
?>    <?php
echo $count;
      ?><i class="
      fa fa-spinner fa-pulse"></i></div>
      <p style="color: white;border-top:1px solid white" >View All Lodges<i class="fa fa-send-o"></i></p>
    </div>

  </div>
  
  </div>

</div>

</div>




  <?php include 'inc/footer.php'; 
  include 'inc/navscript.php';
  ?>
  </body>
  </html>
